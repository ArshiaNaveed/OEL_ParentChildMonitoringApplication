package com.example.arshiaoel;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ChildActivity3 extends AppCompatActivity {

    Button btnback2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_child3);
        btnback2=(Button) findViewById(R.id.btnback2);
    }
    public void onbtnClicked2(View v){
        Intent i=new Intent(this,ChildDashboard.class);
        startActivity(i);
    }
}