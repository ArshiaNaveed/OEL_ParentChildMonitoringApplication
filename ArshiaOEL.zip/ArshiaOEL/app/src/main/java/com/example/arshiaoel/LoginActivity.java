package com.example.arshiaoel;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
Button btnlogin;
EditText username,password;
    int count;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        btnlogin=(Button) findViewById(R.id.btnlogin);
        username=(EditText) findViewById(R.id.edtusername);
        password=(EditText) findViewById(R.id.edtpass);
        count=0;
    }
    public void onClick(View v) {
        count = count+1;
        if(count<3)
        {
            if (username.getText().toString().equals("arshia484") && password.getText().toString().equals("arshia")) {
                username.setText("");
                password.setText("");
                Intent i=new Intent(this,ChildDashboard.class);
                startActivity(i);
            } else if (username.getText().toString().equals("") || password.getText().toString().equals("")) {
                Toast.makeText(getApplicationContext(), "Fill the above fields", Toast.LENGTH_SHORT).show();
                count=0;
            } else {
                Toast.makeText(getApplicationContext(), "Invalid Credentials", Toast.LENGTH_SHORT).show();
            }
        }
        else if(count==3){
            if (username.getText().toString().equals("naveed123") && password.getText().toString().equals("naveed")) {
                count=0;
                Intent i=new Intent(this,ParentDashboard.class);
                startActivity(i);
            } else if (username.getText().toString().equals("") || password.getText().toString().equals("")) {
                Toast.makeText(getApplicationContext(), "Missing fields", Toast.LENGTH_SHORT).show();
                count=0;
            } else {
                Toast.makeText(getApplicationContext(), "Invalid Credentials", Toast.LENGTH_SHORT).show();
                count=0;
            }
        }
        else
        {
            Toast.makeText(getApplicationContext(),"Incomplete fields", Toast.LENGTH_SHORT).show();
            count=0;
        }
    }
}