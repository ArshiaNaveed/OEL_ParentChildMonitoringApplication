package com.example.arshiaoel;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ChildrenReports extends AppCompatActivity {
    Button btnback;
    public static TextView txtLog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_children_reports);
        btnback=(Button) findViewById(R.id.btnback);
        txtLog=(TextView) findViewById(R.id.txtLog);
        txtLog.setMovementMethod(new ScrollingMovementMethod());
    }
    public void onbtnback(View v){
        Intent i=new Intent(this,ParentDashboard.class);
        startActivity(i);
    }
}